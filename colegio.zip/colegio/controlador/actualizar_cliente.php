<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('../include/conexion.php');

    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $cedula = $_POST['cedula'];
    $telefono = $_POST['telefono'];

    // Actualizar el usuario en la base de datos
    $sql = "UPDATE clientes SET nombre='$nombre', cedula='$cedula', telefono=$telefono WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "Usuario actualizado correctamente";
        header("Location: ../template/clientes.php");
    } else {
        echo "Error al actualizar el usuario: " . $conn->error;
    }

    // Cerrar la conexión a la base de datos
    $conn->close();
}
?>