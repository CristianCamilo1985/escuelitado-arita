<?php
session_start();
include '../Conexion/conexion.php';
$td = $_POST['td'];
$numero_doc= $_POST['lbndoc'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$correo = $_POST['correo'];
$cargo = $_POST['cargo'];
$direccion = $_POST['direccion'];



    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['insertar'])){
    $sql = "INSERT INTO empleado (td, numero_documento, nombre, apellido, correo, cargo, direccion,id_salario) 
    VALUES ('$td ',$numero_doc, '$nombre', '$apellido', '$correo', '$cargo', '$direccion','22')";


        if ($conn->query($sql) === TRUE) {
            echo "empleado agregado correctamente.";
            

            header('../public/index2.php');     
        }else{
            echo "error al agregar usuario" .$conn->error;

        }
    }


    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['eliminar'])){
        $sql = "DELETE FROM empleado WHERE numero_documento = $numero_doc ";


        if ($conn->query($sql) === TRUE) {
            echo "empleado eliminado correctamente.";
            

            header('../public/index2.php');    
        }else{
            echo "error al agregar usuario" .$conn->error;

        }
        
    }
  


    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['editar'])){

        $sql="UPDATE empleado SET td='$td',nombre='$nombre',apellido='$apellido',correo='$correo',cargo='$cargo',direccion='$direccion' WHERE numero_documento=$numero_doc";
        if ($conn->query($sql) === TRUE) {
            echo "empleado editado correctamente.";
            

            header('../public/index2.php');     
        }else{
            echo "error al agregar usuario" .$conn->error;

        }
    }

   
?>