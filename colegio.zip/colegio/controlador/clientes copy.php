<?php
session_start();

include ('../include/conexion.php');

// Verificar si hay una sesión iniciada
if (isset ($_SESSION['usuario_rol'])) {
    // Si el usuario no es un administrador, redirigirlo a una página de acceso denegado o a una página adecuada para los empleados
    if ($_SESSION['usuario_rol'] !== 'Administrador') {
        header("Location: ../template/inicio_sesion.php"); // Ruta para la página de acceso denegado
        exit();
    }
} else {
    // Si no hay una sesión iniciada, redirigir al usuario al formulario de inicio de sesión
    header("Location: ../template/inicio_sesion.php"); // Ruta para el formulario de inicio de sesión
    exit();
}
include '../include/cuotas_hoy.php';

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/css.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="../js/functions.js"></script>
    <title>Formulario Agregar Usuario</title>
</head>

<body>

    <div class="divisor">
        <div class="cartas">

            <a class="boton-cerrar" href="../config/cerrar_sesion.php">Cerrar Sesión</a>

            <div class="floating-icon">
                <a href="../config/cuotas_pendientes.php">
                    <i class="fas fa-exclamation-circle"></i>
                    <span class="notification-icon">
                        <?php echo $num_cuotas_pendientes; ?>
                    </span>
                </a>
            </div>

            <div class="card" onclick="window.location.href = '../template/clientes.php'">
                <i class="fa fa-user"></i>
            </div>
            <div class="card" onclick="window.location.href = '../template/prestamo.php'">
                <i class="fa fa-credit-card"></i>
            </div>
            <div class="card" onclick="window.location.href = '../template/reportes.php'">
                <i class="fa fa-clipboard"></i>
            </div>
        </div>

        <div class="separador">

            <div class="der">

                <form id="agregarUsuarioForm" action="../config/agregar_usuario.php" method="POST">
                    <h2>Agregar Usuario</h2>
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" required><br>
                    <span id="errorNombre" class="error"></span><br>

                    <label for="cedula">Cédula:</label>
                    <input type="text" id="cedula" name="cedula" required><br>
                    <?php
                    if (isset ($_GET["error"]) && $_GET["error"] == "cedula") {
                        echo "<span id='errorCedula' class='error'>La cédula ya está registrada</span><br>";
                    }
                    ?>
                    <span id="errorCedula" class="error"></span><br>

                    <label for="telefono">Teléfono:</label>
                    <input type="text" id="telefono" name="telefono"><br>
                    <span id="errorTelefono" class="error"></span><br>

                    <input type="submit" id="submitBtn" value="Agregar">
                </form>
            </div>

            <div class="izq">
                <div class="overflow">
                    <table>

                        <!-- <h2>Usuarios Agregados</h2> -->
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Cédula</th>
                                <th>Teléfono</th>
                                <th>Historial</th>
                                <th>Acciones</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Incluir el archivo de conexión
                            include '../include/conexion.php';

                            // Consulta SQL para obtener clientes
                            $sql = "SELECT * FROM clientes";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // Mostrar los datos de cada usuario en la tabla
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["nombre"] . "</td>";
                                    echo "<td>" . $row["cedula"] . "</td>";
                                    echo "<td>" . $row["telefono"] . "</td>";
                                    // Agregar botón Historial con un enlace a la página de historial de préstamos del usuario
                                    echo "<td><a href='historial_prestamos.php?usuario_id=" . $row["id"] . "' class='btn-historial'>Historial</a></td>";

                                    echo "<td class='opciones'>";

                                    echo "<button class='btn-editar' onclick='abrirModalEditarUsuario(\"{$row['id']}\",\"{$row['nombre']}\", \"{$row['cedula']}\", \"{$row['telefono']}\")'>";
                                    echo "<i class='fas fa-edit'></i> Editar";
                                    echo "</button>";

                                    echo "<input type='hidden' name='cedula' value='{$row['cedula']}'>";
                                    echo "<button class='btn-eliminar' type='button' name='eliminar' onclick='eliminarClientes({$row['cedula']})'><i class='fas fa-trash'></i> Eliminar</button>";

                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5'>No hay clientes registrados</td></tr>";
                            }
                            ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>

        <div id="overlay" class="overlay"></div>
        <div id="modalEditarUsuario" class="modal">

            <span id="btnCerrarModalEditar"
                style="cursor: pointer; position: absolute; top: 10px; right: 10px; font-size: 50px;">&times;</span>

            <div class="centrar_form">
                <div class="form_registrar">
                    <h2><i class="fa fa-edit"></i>Editar Usuario</h2>
                    <form action="../config/actualizar_cliente.php" method="post"
                        onsubmit="return validarFormularioEditarUsuario()">

                        <div>
                            <label for="NombreEditar">Nombre:</label>
                            <input type="text" name="nombre" id="NombreEditar" required>
                        </div>

                        <div>
                            <label for="CedulaEditar">Cedula:</label>
                            <input type="text" name="cedula" id="CedulaEditar" required>
                        </div>

                        <div>
                            <label for="TelefonoEditar">Telefono:</label>
                            <input type="text" name="telefono" id="TelefonoEditar" required>
                        </div>

                        <input type="hidden" name="id" id="IdUsuarioedit">

                        <input type="submit" value="Actualizar">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>

        function abrirModalEditarUsuario(id, nombre, cedula, telefono) {
            document.getElementById('modalEditarUsuario').style.display = 'block';
            document.getElementById('overlay').style.display = 'block';

            document.getElementById('IdUsuarioedit').value = id;
            document.getElementById('NombreEditar').value = nombre;
            document.getElementById('CedulaEditar').value = cedula;
            document.getElementById('TelefonoEditar').value = telefono;
        }

        document.getElementById('btnCerrarModalEditar').addEventListener('click', function () {
            document.getElementById('modalEditarUsuario').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        });

        document.getElementById('overlay').addEventListener('click', function (event) {
            if (event.target === this) { // Verifica si el clic ocurrió en el fondo oscuro
                document.getElementById('modalEditarUsuario').style.display = 'none';
                this.style.display = 'none';
            }
        });
    </script>

    <script>
        document.getElementById('submitBtn').addEventListener('click', function (event) {
            // Evitar que el formulario se envíe automáticamente
            event.preventDefault();

            var nombre = document.getElementById('nombre').value;
            var cedula = document.getElementById('cedula').value;
            var telefono = document.getElementById('telefono').value;

            var errorNombre = document.getElementById('errorNombre');
            var errorCedula = document.getElementById('errorCedula');
            var errorTelefono = document.getElementById('errorTelefono');

            var regexSoloLetras = /^[a-zA-Z ]*$/;
            var regexSoloNumeros = /^[0-9]*$/;

            // Variable para controlar si hay errores
            var hayErrores = false;

            // Validación de nombre
            if (!nombre.match(regexSoloLetras)) {
                errorNombre.textContent = 'El nombre solo puede contener letras y espacios.';
                hayErrores = true;
            } else {
                errorNombre.textContent = '';
            }

            // Validación de cédula
            if (!cedula.match(regexSoloNumeros)) {
                errorCedula.textContent = 'La cédula debe contener solo números.';
                hayErrores = true;
            } else {
                errorCedula.textContent = '';
                // Si la validación de cédula pasa, hacemos una petición AJAX para verificar si ya está en uso
                var xhr = new XMLHttpRequest();
                xhr.open('GET', '../config/verificar_cedula.php?cedula=' + cedula, true);
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.error) {
                            var errorCedulaExistente = document.createElement('span');
                            errorCedulaExistente.className = 'error';
                            errorCedulaExistente.textContent = response.message;
                            document.getElementById('cedula').insertAdjacentElement('afterend', errorCedulaExistente);
                            hayErrores = true;
                            checkErrors();
                        }
                    }
                };
                xhr.send();
            }

            // Validación de teléfono
            if (telefono !== '' && !telefono.match(regexSoloNumeros)) {
                errorTelefono.textContent = 'El teléfono debe contener solo números.';
                hayErrores = true;
            } else {
                errorTelefono.textContent = '';
            }

            // Función para verificar si hay errores y enviar el formulario
            function checkErrors() {
                if (!hayErrores) {
                    document.getElementById('agregarUsuarioForm').submit();
                }
            }

            // Verificar si hay errores y enviar el formulario
            checkErrors();
        });
    </script>

</body>

</html>