<?php
include('../include/conexion.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si se ha enviado un formulario con el botón "Eliminar"

    $cedula = $_POST['cedula'];
    // Eliminar el producto de la base de datos

    $stmt = $conn->prepare("DELETE FROM clientes WHERE cedula = ?");
    $stmt->bind_param("s", $cedula);

    if ($stmt->execute()) {
        
        header("Location: ../template/clientes.php"); // Redirigir a la página principal
        exit();
    } else {
        // Error al eliminar
        echo "Error al eliminar el producto: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    return "hola";
} else {
    // Acceso directo al script sin datos POST, redirigir a la página principal
    // header("Location: ../windows/productos.php");
    exit();
}
?>
