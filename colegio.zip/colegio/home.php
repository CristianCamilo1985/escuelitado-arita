<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo/login.css">
    <title>Menú Desplegable</title>

</head>
<body>
    <div class="container">
    <header>
        <div class="logo">
            <img src="img/logo.png" alt="Logo">
        </div>
    </header>
        <nav class="menu">
            <ul>
                <?php
                    // Definir las opciones del menú
                    $menu_items = array(
                        "Home" => "home.php",
                        "Ingresar Animal" => "ingresar_animal.php",
                        "Vender Animal" => "vender_animal.php",
                        "Control Peso" => "peso.php",
                        "Generar Lista Animales" => "lista_animales.php",
                        "Ingresar Animal" => "ingresar_animal.php",
                    );

                    // Generar los elementos del menú
                    foreach ($menu_items as $item => $link) {
                        echo "<li><a href=\"$link\">$item</a></li>";
                    }
                ?>
            </ul>
        </nav>
        <footer>
            © <?php echo date("Y"); ?> Todos los derechos reservados.
        </footer>
    </div>
</body>
</html>
