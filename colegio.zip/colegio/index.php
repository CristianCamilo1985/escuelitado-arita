<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo/indes.css">
    <title>Inicio sesión</title>
</head>
<body>
    
    <main>
        <?php include_once("conexion.php"); ?>
        <div class="contenedor__todo">
            <div class="contenedor__login-register">
            <header>
        <div class="logo">
            <img src="img/logo.jpg" alt="Logo">
        </div>
    </header>
                <form action="iniciar_sesion.php" class="formulario__login" method="post">
                    <h2>Iniciar Sesión</h2>
                    <input type="text" name="nombre_usuario" placeholder="Usuario" required>
                    <input type="password" name="contraseña" placeholder="Contraseña" required>
                    <button type="submit">Entrar</button>
                </form>
                <form action="registro.php" method="post" class="formulario__register">
                    <h2>Registrarse</h2>
                    <input type="float" name="id_usuario" placeholder="Número documento" required>
                    <input type="text" name="nombre_usuario" placeholder="Nombre completo" required>
                    <input type="password" name="contraseña" placeholder="Contraseña" required>
                    
               
                            
                   
                    
                        
                        <select id="rol" name="rol" required>
                            <option value="" disabled selected>Rol</option>
                            <option value="administrador">Administrador</option>
                            <option value="propietario">Instructor</option>
                            <option value="mayordomo">Alumno</option>
                        </select>
               

                    <button name="registroBT">Registrarse</button>
                
                </form>

            </div>
        </div>
        </div>
     
      
    </main>
    <footer>
            © <?php echo date("Y"); ?> Todos los derechos reservados.
        </footer>
    
    <script src="../js/login.js"></script>
</body>

</html>




