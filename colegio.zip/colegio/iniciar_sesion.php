<?php
session_start();
include_once("conexion.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nombre_usuario = $_POST['nombre_usuario'];
    $contraseña = $_POST['contraseña'];

    $sql = "SELECT * FROM usuarios WHERE  	nombre_usuario = ? AND contraseña = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $nombre_usuario, $contraseña);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {

        session_start();
        $_SESSION["loggedin"] = true;
        header("Location: home.php");
        exit();
    } else {

        echo "Usuario o contraseña incorrectos. Por favor, inténtalo de nuevo.";
    }
}

$conn->close();
?>
