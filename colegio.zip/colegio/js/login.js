window.addEventListener("resize", anchoPagina);

var contenedor_login_register = document.querySelector(".contenedor__login-register");
var formulario_login = document.querySelector(".formulario__login");
var formulario_register = document.querySelector(".formulario__register");

function anchoPagina(){
    if(window.innerWidth > 850){
        caja_trasera_login.style.display = "block";
        caja_trasera_register.style.display = "block";
    }else{
        formulario_login.style.display = "block";
        formulario_register.style.display = "none";
        contenedor_login_register.style.left = "0px"
    }
}

anchoPagina();

function iniciarsesion(){
    if (window.innerWidth > 850){
        formulario_register.style.display = "none";
        contenedor_login_register.style.left = "10px";
        formulario_login.style.display = "block";
    }else{
        formulario_register.style.display = "none";
        contenedor_login_register.style.left = "0";
        formulario_login.style.display = "block";
    }
   
}

function register(){
    if(window.innerWidth > 850){
        formulario_register.style.display = "block";
        contenedor_login_register.style.left = "410px";
        formulario_login.style.display = "none";

    }else{
        formulario_register.style.display = "block";
        contenedor_login_register.style.left = "0";
        formulario_login.style.display = "none";
    }
   
}

