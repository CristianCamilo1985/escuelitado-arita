<?php
// Verificar si el usuario está autenticado
session_start();
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // El usuario no está autenticado, redirigirlo al inicio de sesión
    header("Location: index.php");
    exit();
}
